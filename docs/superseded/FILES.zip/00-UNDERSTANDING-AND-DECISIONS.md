# IEEE RAIT Website — Understanding Lock & Decision Log

Status: **draft pending confirmation**. Everything below marked `ASSUMPTION` was
decided without your input so the work could proceed. Correct any of them and the
downstream documents change accordingly.

---

## 1. Understanding Summary

- **What is being built.** A website for the IEEE RAIT Student Branch (D Y Patil
  University / Ramrao Adik Institute of Technology, Navi Mumbai) that wraps the
  existing single-file rocket-ride induction experience (`index.html`, 788 lines,
  zero dependencies) inside a persistent branch site: events, chapters, team,
  registration, and archive.
- **Why it exists.** Two jobs. (a) Convert first-year students into members during
  induction week — the rocket ride already does this and is the strongest asset in
  the folder. (b) Give the branch a year-round surface that survives committee
  handover, so events, the flight log, and the team roster stop living in slide
  decks and WhatsApp.
- **Who it is for.** Primary: first-year RAIT students during induction. Secondary:
  current members looking up what is scheduled; the 18-role junior committee
  maintaining content; faculty, sponsors, and IEEE section reviewers who need a
  credible public face.
- **Key constraints.** No backend and no budget assumed; static hosting.
  Phone-first — induction traffic arrives from a QR code on a projector. The
  existing engine is hand-rolled canvas with no build step, and its content slots
  are still unfilled (`REPLACE_ME` × 5, `EDIT ME` × 8, every `photos[].src`
  empty). Media on disk is 596 MB across 58 files and is unusable as-is.
- **Non-goals.** Not a CMS. Not a login/portal with member accounts. Not a
  payments system. Not a WebGL rebuild of the induction ride. Not multi-language.
  Not a redesign of the induction art direction — that direction is settled and
  good; the reference sites inform the *new* surfaces and the motion grammar, not
  a replacement of the ride.
- **Success criteria.** Induction: ≥60% of ride starts reach waypoint 06, ≥35% of
  arrivals click Register. Year-round: every event published within 72 h of
  happening, with real photos. Handover: a new Chief Web Developer can publish an
  event by editing one data file, no framework knowledge required.

---

## 2. Assumptions

| # | Assumption | Impact if wrong |
|---|---|---|
| A1 | Scope is **extend, not replace**: the rocket ride survives as the induction surface at `/induct`, and a conventional site is built around it. | If you wanted a full redesign in the anime.js/Resn direction, the Design Stack survives but the TRD's "preserve the canvas engine" section is discarded. |
| A2 | Static hosting, no server. Registration stays a Google Form in Phase 1. | A real registration API adds a backend, a database, and the whole of TRD §7 security surface becomes mandatory rather than deferred. |
| A3 | Traffic is small: ~2 000 sessions in induction week, peak ~300 concurrent; ~300/month otherwise. | Only matters for hosting choice; CDN static handles 100× this. |
| A4 | Content is edited by students via a data file in the repo, reviewed by the Chief Web Developer before publish. | If non-technical editors must publish directly, a headless CMS enters the tech stack. |
| A5 | Registration collects name, roll number, department, year, email, phone — PII under DPDP Act 2023. Consent copy is required at collection. | If IEEE membership numbers or payment data are collected, privacy scope escalates sharply. |
| A6 | The reference sites are **grammar references, not templates**: anime.js supplies the motion vocabulary, Resn's Little Helper supplies the "hold to reveal, atmosphere over convention" posture. Neither is to be cloned. | If you want a literal Resn-style WebGL narrative site, Three.js enters the tech stack and the perf budget triples. |
| A7 | Desktop matters but mobile leads. The induction QR is scanned on phones. | Reverses the layout order in the Design Stack. |
| A8 | English only. | i18n would change the content model shape. |

---

## 3. Open Questions

1. **`REPLACE_ME` values.** Real URLs needed for the Google Form, Instagram,
   LinkedIn, and WhatsApp group. The site cannot ship without these four.
2. **Flight log content.** Only *Prompting Odyssey* (01 Aug 26 — six hours, 22
   people, five departments) is real. Three `EDIT ME` slots in `MARS` and four in
   `MOON` need real events with real numbers.
3. **Photo provenance.** The 54 images in `IMG/` are a cybersecurity/networking
   workshop in the RAIT lab (slides show hashing, trojans, targeted attacks;
   faculty Mr Somnath Tandale, subject CCNT). Which event were these, and is
   there student consent to publish faces publicly?
4. **Reference site access.** `littlehelper.resn.global` cannot be fetched — its
   TLS certificate resolves to `*.cloudfront.net` and does not cover the hostname.
   Analysis is from the Awwwards record (Site of the Day, 22 Dec 2017; palette
   `#000` / `#ffffff` / `#FF9398`; WebGL; scroll-driven typography; sound design;
   creativity 8.41, usability 7.26). If there is a live mirror, point me at it.
5. **Domain.** Is there an existing `ieeerait.*` domain or a university subdomain,
   or is `github.io` acceptable for Phase 1?
6. **Handover date.** Committee turnover timing sets the deadline for the docs and
   the content-editing workflow.

---

## 4. Decision Log

| # | Decision | Alternatives considered | Why |
|---|---|---|---|
| D1 | Keep the canvas induction ride; build the branch site around it. | Rebuild in WebGL/Three.js; discard the ride for a conventional site. | The ride is finished, on-brand, zero-dependency, and already handles reduced-motion. Rebuilding spends the whole budget re-earning ground already held. |
| D2 | Multi-page static site, one HTML file per surface, shared CSS/JS. | SPA (React/Vue); single-page scroll site. | No routing library, no hydration, no build step required. Each page ships only what it needs, so the induction ride stays under budget while `/events` can afford anime.js. |
| D3 | anime.js v4 as the only animation dependency, and only outside the ride. | GSAP; CSS-only; hand-rolled rAF everywhere. | ~24 KB modular, tree-shakeable to ~11 KB for timer+animation, MIT, and its v4 API (`createTimeline`, `onScroll({sync:true})`, `createSpring`, `stagger({from:'center'})`) maps directly onto the motion grammar wanted. The canvas ride keeps its own loop — no reason to pay for a library there. |
| D4 | Content lives in `data/*.js` plain objects, hand-edited, reviewed via pull request. | Headless CMS (Sanity/Contentful); Markdown + static generator; Google Sheets. | Matches the existing `CONFIG`/`STOPS` pattern the site already uses, needs no account or API key, and survives handover because it is just JavaScript objects with comments. |
| D5 | Registration via Google Forms in Phase 1; abstracted behind one config value. | Custom form + serverless function + database from day one. | Zero infrastructure, zero PII in our custody, and the Database Administrator role in the committee brief already implies Sheets-based record keeping. Swapping later is a one-line change. |
| D6 | Media pipeline is a mandatory build step, not optional. | Ship the files as-is; rely on the CDN. | 596 MB across 58 files, with three videos at 60/100/137 MB, is roughly 4 000× the microsite image budget. Nothing ships until this is transcoded. |
| D7 | Preserve the existing token set (`--vac`, `--hull`, `--isro`, `--kapton`, `--steel`, `--deck`, `--edge`) and extend rather than re-palette. | New palette informed by Resn's black/white/pink. | The ISRO-orange-on-vacuum-black direction is distinctive, already implemented, and reads as intentional. Resn's contribution is posture and motion, not colour. |
| D8 | Accessibility parity is a release gate, not a phase. | Ship, then retrofit. | The ride already implements `prefers-reduced-motion`, `focus-visible`, `role="dialog"`, and keyboard throttle control. Regressing that on new pages would be a step backwards from the current state. |
